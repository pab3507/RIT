__author__ = 'Moisés Lora'

from rit_lib import *
from train import *

class TrainCar( struct ):
    _slots = ((str, "content"), (('TrainCar', NoneType), "next"))

